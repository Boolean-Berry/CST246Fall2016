package queues;

public class Queue {
	private long[] queArray;
	private int maxSize;
	private int front;
	private int rear;
	private int nElems;
	
	public Queue(int s) {
		maxSize = s;
		queArray = new long[maxSize];
		front = 0;
		rear = -1;
		nElems = 0;
	}
	
	public void insert(long j) {
		if(rear == maxSize - 1) {
			rear = -1;  // wrap around
		}
		queArray[++rear] = j;
		nElems++;
	}
	
	public long remove(){
		long temp = queArray[front++];
		if(front == maxSize) {
			front = 0;
		}
		nElems--;
		return temp;
	}
	
	public long peekFront() {
		return queArray[front];
	}
	
	public boolean isEmpty() {
		return nElems == 0;
	}

	public boolean isFull(){
		return nElems == maxSize;
	}
	
	public int size() {
		return nElems;
	}
}
